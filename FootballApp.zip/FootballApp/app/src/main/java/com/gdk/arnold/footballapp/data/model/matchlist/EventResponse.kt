package com.gdk.arnold.footballapp.data.model.matchlist

data class EventResponse(

    val events: List<EventsItem>
)
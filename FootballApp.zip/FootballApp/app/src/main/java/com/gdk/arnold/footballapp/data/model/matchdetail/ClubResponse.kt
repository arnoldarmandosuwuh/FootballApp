package com.gdk.arnold.footballapp.data.model.matchdetail

data class ClubResponse(

    val teams: List<TeamsItem>
)